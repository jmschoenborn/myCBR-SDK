/*
 * Decompiled with CFR 0.150.
 */
package de.dfki.mycbr.maintenance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class MaintenanceController {
    
    private static final Logger LOGGER = LogManager.getLogger(MaintenanceController.class);
    
    private List<MaintenanceMap> maintenancemaps = new ArrayList<MaintenanceMap>();

    public boolean addMaintenanceMap(MaintenanceMap mmap) {
        boolean added = false;
        MaintenanceMap m = this.findMaintenanceMap(mmap.getName());
        if (m == null) {
            this.maintenancemaps.add(mmap);
            added = true;
        }
        return added;
    }

    public boolean addMaintenanceMap(String name, boolean type) {
        MaintenanceMap m = null;
        m = type ? new LocalMaintenanceMap(name, type) : new GlobalMaintenanceMap(name, type);
        return this.addMaintenanceMap(m);
    }

    public MaintenanceMap findMaintenanceMap(String name) {
        MaintenanceMap map = null;
        for (MaintenanceMap m : this.maintenancemaps) {
            if (!m.getName().equals(name)) continue;
            map = m;
        }
        return map;
    }

    public MaintenanceMap loadMaintenanceMap(String filename) {
        MaintenanceMap mmap = null;
        try {
            FileInputStream fis = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Object map = ois.readObject();
            ois.close();
            fis.close();
            if (map instanceof LocalMaintenanceMap) {
                mmap = (LocalMaintenanceMap)map;
            } else if (map instanceof GlobalMaintenanceMap) {
                mmap = (GlobalMaintenanceMap)map;
            }
        }
        catch (FileNotFoundException e) {
            LOGGER.error("FileNotFoundException in loadMaintenanceMap()", e);
        }
        catch (IOException e) {
            LOGGER.error("IOException in loadMaintenanceMap()", e);
        }
        catch (ClassNotFoundException e) {
            LOGGER.error("ClassNotFoundException in loadMaintenanceMap()", e);
        }
        return mmap;
    }

    public void loadAllMaintenanceMaps() {
        File[] mmap_files;
        File directory = new File(MaintenanceMap.class.getClassLoader().getResource("MaintenanceMap.class").getPath());
        File[] arrfile = mmap_files = directory.listFiles();
        int n = mmap_files.length;
        for (int i = 0; i < n; ++i) {
            File f = arrfile[i];
            if (!f.getName().contains("MMAP")) continue;
            try {
                FileInputStream fis = new FileInputStream(f);
                ObjectInputStream ois = new ObjectInputStream(fis);
                Object map = ois.readObject();
                MaintenanceMap mmap = null;
                if (map instanceof LocalMaintenanceMap) {
                    mmap = (LocalMaintenanceMap)map;
                } else if (map instanceof GlobalMaintenanceMap) {
                    mmap = (GlobalMaintenanceMap)map;
                }
                this.maintenancemaps.add(mmap);
                ois.close();
                fis.close();
                continue;
            }
            catch (FileNotFoundException e) {
                LOGGER.error("FileNotFoundException in loadAllMaintenanceMaps()", e);
                continue;
            }
            catch (ClassNotFoundException e) {
                LOGGER.error("ClassNotFoundExceptions in loadAllMaintenanceMaps()", e);
                continue;
            }
            catch (IOException e) {
                LOGGER.error("IOException in loadAllMaintenanceMaps()", e);
            }
        }
    }
}

