/*
 * Decompiled with CFR 0.150.
 */
package de.dfki.mycbr.maintenance;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class MaintenanceMap implements Serializable {
    private static final long serialVersionUID = 7778433263494245024L;
    private String name;
    private boolean type;
    private List<Dependency> dependencies;

    public MaintenanceMap(String name, boolean type) {
        this.name = name;
        this.type = type;
        this.dependencies = new ArrayList<Dependency>();
    }

    public void addDependency(Dependency dep) {
        this.dependencies.add(dep);
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isType() {
        return this.type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public List<Dependency> getDependencies() {
        return this.dependencies;
    }

    public void saveMaintenanceMap() throws IOException {
        FileOutputStream fos = new FileOutputStream("MMAP_" + this.name);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(this);
        oos.close();
        fos.close();
    }
}

