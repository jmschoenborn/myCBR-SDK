/**
 * Contains utility classes that are useful but do not have a special 
 * meaning for case-based reasoning applications.
 * 
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package de.dfki.mycbr.util;
