/**
 * Contains various enumerations specifying configurations
 * for the corresponding similarity function.
 * 
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package de.dfki.mycbr.core.similarity.config;
