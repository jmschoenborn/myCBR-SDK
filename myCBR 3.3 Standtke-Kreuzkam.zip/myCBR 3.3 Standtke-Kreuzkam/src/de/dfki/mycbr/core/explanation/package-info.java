/**
 * Explanations provide additional information on all
 * myCBR concepts.
 * 
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package de.dfki.mycbr.core.explanation;
