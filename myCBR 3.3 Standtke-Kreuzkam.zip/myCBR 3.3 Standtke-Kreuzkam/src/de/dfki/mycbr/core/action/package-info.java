/**
 * Defines classes for specifying actions that operate on
 * <code>Observable</code> objects.
 *
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package de.dfki.mycbr.core.action;

