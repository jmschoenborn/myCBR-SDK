/**
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package test.junittest;
