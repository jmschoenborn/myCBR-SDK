/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.subtaxonomies.compilation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomy;
import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomyNode;

// TODO: Auto-generated Javadoc
/**
 * The Class TaxonomyCompiler.
 *
 * @author myCBR Team
 */
public class TaxonomyCompiler {

	/** The Constant SEPARATOR. */
	private char separator = ':';

	/** The Constant qualifiedNames. */ 
	private boolean qualifiedNames = true;

	private Collection<String> compiledNames = null;
	
	private Map<String, SubTaxonomy> taxonomyMap = new HashMap<String, SubTaxonomy>();

	public TaxonomyCompiler() {

	}

	public TaxonomyCompiler(char separator, boolean qualifiedNames) {
		this.separator = separator;
		this.qualifiedNames = qualifiedNames;
	}

	public void addTaxonomy(SubTaxonomy tax) {
		taxonomyMap.put(tax.getId(), tax);
	}

	public boolean addTaxonomy(SubTaxonomy tax, boolean replaceExisting) {
		boolean taxonomyAdded = false;
		if (taxonomyMap.get(tax.getId()) != null || replaceExisting) {
			taxonomyMap.put(tax.getId(), tax);
			taxonomyAdded = true;
		}
		return taxonomyAdded;
	}

	public SubTaxonomy getTaxonomy(String id) {
		return taxonomyMap.get(id);
	}
	
	public Collection<SubTaxonomy> getTaxonomies() {
		return taxonomyMap.values();
	}

	public boolean removeTaxonomy(String id) {
		return taxonomyMap.remove(id) != null;
	}

	/**
	 * Compile taxonomy fct.
	 *
	 * @param taxonomy
	 *            the taxonomy
	 * @return the sub taxonomy node
	 * @throws Exception
	 *             the exception
	 */
	public SubTaxonomyNode compileTaxonomy(SubTaxonomy taxonomy) throws Exception {
		
		SubTaxonomyNode compiledTaxonomyRootNode = new SubTaxonomyNode();

		compiledNames = new ArrayList<String>();
		
		List<String> predecessorSubTaxonomies = new ArrayList<String>();
		predecessorSubTaxonomies.add(taxonomy.getId());

		compileNode(compiledTaxonomyRootNode, taxonomy.getRootNode(), 0d, 0d, "", predecessorSubTaxonomies);

		return compiledTaxonomyRootNode;
	}

	/**
	 * @return the separator
	 */
	public char getSeparator() {
		return separator;
	}

	/**
	 * @param separator
	 *            the separator to set
	 */
	public void setSeparator(char separator) {
		this.separator = separator;
	}

	/**
	 * Modifies the parameters of the compiledNode depending on the context
	 * defined by referencingSim and rootSim. Recursively attaches all
	 * childnodes of the sourceNode to the compiledNode. Takes children that are
	 * attached directly as well as children that are only attached by reference
	 * to another taxonomy.
	 *
	 * @param compiledNode
	 *            compiled version of the node
	 * @param sourceNode
	 *            the source node from the subtaxonomy-structure
	 * @param referencingSim
	 *            the referencing sim
	 * @param rootSim
	 *            the root sim
	 * @param prefix
	 *            the prefix
	 * @param predecessorSubTaxonomies
	 *            list of all predecessor Taxonomies visited before this
	 *            function call
	 * @throws MinHeapViolationException
	 *             the min heap violation exception
	 * @throws TaxonomyCycleException
	 *             the taxonomy cycle exception
	 * @throws DuplicateIdentifierException 
	 */
	private void compileNode(SubTaxonomyNode compiledNode, SubTaxonomyNode sourceNode, double referencingSim,
			double rootSim, String prefix, List<String> predecessorSubTaxonomies)
			throws MinHeapViolationException, TaxonomyCycleException, DuplicateIdentifierException {

		String newId = prefix + sourceNode.getId();
		if (!compiledNames.contains(newId)){
			compiledNode.setId(newId);
			compiledNames.add(newId);
		} else {
			throw new DuplicateIdentifierException(newId);
		}
		compiledNode.setSimilarity(DefaultAdaptionFormula.formula(referencingSim, rootSim, sourceNode.getSimilarity()));

		String newPredecessorSubTaxonomy = null;

		// If node is referencing node and the referenced tree can be found ->
		// adjust context parameters
		if (sourceNode.isReferencingNode() && this.taxonomyMap.get(sourceNode.getReferencedTreeId()) != null) {
			// Get rootSim from rootNode of the referenced taxonomy
			SubTaxonomy referencedTree = this.taxonomyMap.get(sourceNode.getReferencedTreeId());

			newPredecessorSubTaxonomy = sourceNode.getReferencedTreeId();

			rootSim = referencedTree.getRootNode().getSimilarity();

			referencingSim = compiledNode.getSimilarity();

			if (qualifiedNames) {
				prefix += sourceNode.getDirectParent().getId() + separator;
			}

			// Finally readjust the values of the compiled node
			compiledNode.setSimilarity(DefaultAdaptionFormula.formula(referencingSim, rootSim, rootSim));
			compiledNode.setId(prefix + referencedTree.getRootNode().getId());

			/*
			 * Change sourcenode in order to compile the children of referenced
			 * node because the referencing node itself does not have any
			 * children
			 */
			sourceNode = referencedTree.getRootNode();
		}

		/*
		 * Before Compilation of the children, the next step is to ensure that a
		 * correct list of predecessors gets passed on. If a circle is
		 * identified, the compilation stops and an TaxonomyCycleException gets
		 * thrown.
		 */

		// Create a new list of predecessorSubTaxonomies if there is a new
		// predecessorTaxonomy to add
		List<String> newPredecessorSubTaxonomies = null;
		if (newPredecessorSubTaxonomy != null && !predecessorSubTaxonomies.contains(newPredecessorSubTaxonomy)) {
			newPredecessorSubTaxonomies = new ArrayList<String>();
			newPredecessorSubTaxonomies.addAll(predecessorSubTaxonomies);
			newPredecessorSubTaxonomies.add(newPredecessorSubTaxonomy);
			// if the taxonomy referenced in the current method call has already
			// been visited before that indicates a cycle
		} else if (newPredecessorSubTaxonomy != null && predecessorSubTaxonomies.contains(newPredecessorSubTaxonomy)) {
			throw new TaxonomyCycleException(predecessorSubTaxonomies, newPredecessorSubTaxonomy);
		}

		// compile each child of the node
		for (SubTaxonomyNode sourceChild : sourceNode.getChildren()) {

			checkMinHeapCondition(sourceChild);

			SubTaxonomyNode compiledChild = new SubTaxonomyNode();
			compiledNode.addChild(compiledChild);

			// if no new predecessor was found, pass the old predecessor list as
			// it remains the same
			if (newPredecessorSubTaxonomy == null) {
				compileNode(compiledChild, sourceChild, referencingSim, rootSim, prefix, predecessorSubTaxonomies);
				// Otherwise pass the new predecessor-list
			} else {
				compileNode(compiledChild, sourceChild, referencingSim, rootSim, prefix, newPredecessorSubTaxonomies);
			}

		}

	}

	/**
	 * @return the qualifiedNames
	 */
	public boolean isQualifiedNames() {
		return qualifiedNames;
	}

	/**
	 * @param qualifiedNames
	 *            the qualifiedNames to set
	 */
	public void setQualifiedNames(boolean qualifiedNames) {
		this.qualifiedNames = qualifiedNames;
	}

	/**
	 * Removes all Taxonomies from the Compiler.
	 */
	public void removeAll() {
		this.taxonomyMap.clear();
	}
	
	/**
	 * Check min heap condition.
	 *
	 * @param child
	 *            the child
	 * @throws MinHeapViolationException
	 *             the min heap violation exception
	 */
	private void checkMinHeapCondition(SubTaxonomyNode child) throws MinHeapViolationException {
		if (child.getDirectParent() != null) {
			if (child.getDirectParent().getSimilarity() > child.getSimilarity()) {
				throw new MinHeapViolationException(child);
			}

		}

	}

}
