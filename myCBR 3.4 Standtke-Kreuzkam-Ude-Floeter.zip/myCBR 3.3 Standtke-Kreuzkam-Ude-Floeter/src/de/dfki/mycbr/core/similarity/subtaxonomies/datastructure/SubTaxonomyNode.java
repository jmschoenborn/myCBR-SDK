
/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.subtaxonomies.datastructure;

import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * Created by moritz on 27/04/16.
 */
public class SubTaxonomyNode {

	/** The children. Stores all child nodes that are attached to this node */
	private ArrayList<SubTaxonomyNode> children = new ArrayList<SubTaxonomyNode>();

	/**
	 * directParent stores the parent node where this node is contained in the
	 * children-attribute It will NOT store any parent which is member of
	 * another tree.
	 */
	private SubTaxonomyNode directParent = null;
	

	/** The referenced tree id. Stores reference to another tree. */
	private String referencedTreeId = null;

	/** The similarity. */
	private double similarity = 0;

	/** The id. Unique identifier of the node */
	private String id = "";

	/**
	 * Instantiates a new Tree node.
	 */
	public SubTaxonomyNode() {

	}

	/**
	 * Gets the root sub taxonomy node.
	 *
	 * @return the root sub taxonomy node
	 */
	public SubTaxonomyNode getRootSubTaxonomyNode() {

		SubTaxonomyNode rootCandidate = this;

		while (rootCandidate.directParent != null) {
			rootCandidate = rootCandidate.directParent;
		}
		return rootCandidate;
	}

	/**
	 * Gets id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets id.
	 *
	 * @param id
	 *            the id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Add child.
	 *
	 * @param node
	 *            the node
	 */
	public void addChild(SubTaxonomyNode node) {
		if (this.referencedTreeId == null) {
			this.children.add(node);

			// remove child from former parents children
			if (node.directParent != null) {
				node.directParent.removeChild(node);
			}

			node.directParent = this;

		} else {
			// TODO: Exception -> either reference or children
		}

	}

	/**
	 * Set referenced treeid.
	 *
	 * @param treeId
	 *            the tree id
	 */
	public void setReferencedTreeId(String treeId) {
		if (children.size() > 0) {
			// TODO: Exception -> either reference or children
		} else {
			this.referencedTreeId = treeId;
		}

	}

	/**
	 * Is referencing node boolean.
	 *
	 * @return the boolean
	 */
	public boolean isReferencingNode() {
		return (this.referencedTreeId != null);
	}

	/**
	 * Gets referenced tree id.
	 *
	 * @return the referenced tree id
	 */
	public String getReferencedTreeId() {
		return this.referencedTreeId;
	}

	/**
	 * Gets similarity.
	 *
	 * @return the similarity
	 */
	public double getSimilarity() {
		return similarity;
	}

	/**
	 * Sets similarity.
	 *
	 * @param similarity
	 *            the similarity
	 */
	public void setSimilarity(double similarity) {
		this.similarity = similarity;
	}

	/**
	 * Remove child. Does only work on directly attached children. Get the root
	 * node of a referenced tree and perform this method on it if you want to
	 * delete referenced children.
	 *
	 * @param node
	 *            the node
	 */
	public void removeChild(SubTaxonomyNode node) {
		node.directParent = null;
		this.children.remove(node);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return this.getId() + ", sim=" + this.getSimilarity();
	}

	/**
	 * Removes node from its parent.
	 */
	public void removeFromParent() {
		this.directParent.removeChild(this);
	}

	/**
	 * Removes the all children.
	 */
	public void removeAllChildren() {
		
		while (!children.isEmpty()) {
			this.removeChild(children.get(0));
		}

	}

	/**
	 * Gets a list of all children.
	 *
	 * @return the children
	 */
	public List<SubTaxonomyNode> getChildren() {
		List<SubTaxonomyNode> children = new ArrayList<SubTaxonomyNode>();
		children.addAll(this.children);
		return children;
	}


	/**
	 * @return
	 */
	public SubTaxonomyNode getDirectParent() {
		return this.directParent;
	}

}
