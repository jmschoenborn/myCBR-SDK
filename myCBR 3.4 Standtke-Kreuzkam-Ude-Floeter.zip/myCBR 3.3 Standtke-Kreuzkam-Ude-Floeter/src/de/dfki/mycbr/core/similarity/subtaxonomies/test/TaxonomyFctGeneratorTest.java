/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.subtaxonomies.test;

import static org.junit.Assert.*;

import org.junit.Test;

import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.SymbolDesc;
import de.dfki.mycbr.core.similarity.config.TaxonomyConfig;
import de.dfki.mycbr.core.similarity.subtaxonomies.compilation.TaxonomyCompiler;
import de.dfki.mycbr.core.similarity.subtaxonomies.compilation.TaxonomyFctGenerator;
import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomy;
import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomyNode;

/**
 * @author myCBR Team
 *
 */
public class TaxonomyFctGeneratorTest {

	@Test
	public void test() {
		Project p = null;
		try {
			p = new Project();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		Concept c = null;
		try {
			c = p.createTopConcept("top");
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		SubTaxonomy rootTaxonomy = new SubTaxonomy("rootTaxonomy");
		SubTaxonomyNode taxonomyRootNode = rootTaxonomy.getRootNode();
		taxonomyRootNode.setId("rootOfRoot");
		taxonomyRootNode.setSimilarity(0.0);

		SubTaxonomyNode virginChildOfRoot = new SubTaxonomyNode();
		virginChildOfRoot.setId("virginOfRoot");
		virginChildOfRoot.setSimilarity(0.8);
		SubTaxonomyNode referencingChildOfRoot = new SubTaxonomyNode();
		referencingChildOfRoot.setId("referencingChildOfRoot");
		referencingChildOfRoot.setSimilarity(0.4);
		referencingChildOfRoot.setReferencedTreeId("subTaxonomy");

		taxonomyRootNode.addChild(virginChildOfRoot);
		taxonomyRootNode.addChild(referencingChildOfRoot);

		SubTaxonomy subTaxonomy = new SubTaxonomy("subTaxonomy");
		SubTaxonomyNode subTaxonomyRootNode = subTaxonomy.getRootNode();
		subTaxonomyRootNode.setId("rootOfSubtaxonomy");
		subTaxonomyRootNode.setSimilarity(0.0);

		SubTaxonomyNode child1 = new SubTaxonomyNode();
		child1.setId("child1");
		child1.setSimilarity(0.5);
		SubTaxonomyNode child2 = new SubTaxonomyNode();
		child2.setId("child2");
		child2.setSimilarity(0.5);
		
		SubTaxonomyNode childOfChild2 = new SubTaxonomyNode();
		childOfChild2.setId("childOfChild2");
		childOfChild2.setSimilarity(1);
		child2.addChild(childOfChild2);

		subTaxonomyRootNode.addChild(child1);
		subTaxonomyRootNode.addChild(child2);

		SubTaxonomyNode compiledTaxonomyRootNode = null;
		try {
			TaxonomyCompiler compiler = new TaxonomyCompiler();
			compiler.addTaxonomy(rootTaxonomy);
			compiler.addTaxonomy(subTaxonomy);
			compiledTaxonomyRootNode = compiler.compileTaxonomy(rootTaxonomy);
		} catch (Exception e) {
			fail("Compilation failed" + e);
		}

		SymbolDesc sd = null;
		try {
//			sd = TaxonomyFctGenerator.subTaxonomyToTaxonomyFct(compiledTaxonomyRootNode, "MyCrazyTax", c, TaxonomyConfig.INNER_NODES_PESSIMISTIC);
		} catch (Exception e) {
			e.printStackTrace();
		}

		String[] list = sd.getAllowedValues().toArray(new String[sd.getAllowedValues().size()]);
		for (String string : list) {
			for (String string2 : list) {
				try {
					System.out.println(string + " " + string2 + " " + sd.getFct("MyCrazyTax")
							.calculateSimilarity(sd.getAttribute(string), sd.getAttribute(string2)));
				} catch (Exception e) {
					fail("error in the structure of the generated Taxonomy");
					e.printStackTrace();
				}

			}
		}
	}
}
