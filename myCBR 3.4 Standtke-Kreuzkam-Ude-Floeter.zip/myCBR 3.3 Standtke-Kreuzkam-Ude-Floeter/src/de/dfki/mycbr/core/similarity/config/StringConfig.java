/*
 * myCBR License 3.0
 * 
 * Copyright (c) 2006-2015, by German Research Center for Artificial Intelligence (DFKI GmbH), Germany
 * 
 * Project Website: http://www.mycbr-project.net/
 * 
 * This library is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU Lesser General Public License as published by 
 * the Free Software Foundation; either version 3 of the License, or 
 * (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License 
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 * 
 * Oracle and Java are registered trademarks of Oracle and/or its affiliates. 
 * Other names may be trademarks of their respective owners.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.config;

import java.util.Arrays;

/**
 * Lists the function types which can be used for similarity computation of
 * strings.
 *
 * @author myCBR Team
 *
 */
public enum StringConfig {

    /**
     * Equality function
     */
    EQUALITY("Equality", new String[0], new Number[0], new Number[0], new Number[0], new boolean[0]),

    /**
     * Use n-grams for similarity.
     */
    NGRAM("NGram", new String[] { "N" }, new Number[] { 1 }, new Number[] { Integer.MAX_VALUE }, new Number[] { 3 },
            new boolean[] { true }),

    /**
     * Use levenshtein for similarity
     */
    LEVENSHTEIN("Levenshtein", new String[] { "Addition Cost", "Deletion Cost", "Change Cost" },
            new Number[] { 1, 1, 1 }, new Number[] { Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE },
            new Number[] { 1, 1, 1 }, new boolean[] { true, true, true });

    /**
     * The name of the Config
     */
    private String displayName;

    /**
     * The names of the parameter
     */
    private String[] paramNames;

    /**
     * The minimum values
     */
    private Number[] mins;

    /**
     * the maximum values
     */
    private Number[] maxs;

    /**
     * the default values
     */
    private Number[] defaults;

    /**
     * the types of each parameter
     */
    private boolean[] useIntegers;

    /**
     * Create a new StringConfig.
     * 
     * @param name        the display name
     * @param paramNames  the names of the parameters
     * @param mins        the minimum value for each parameter
     * @param maxs        the maximum value for each parameter
     * @param defaults    the default value for each parameter
     * @param useIntegers set for every type if its a floating point or integer
     *                    number
     */
    StringConfig(String name, String[] paramNames, Number[] mins, Number[] maxs, Number[] defaults,
            boolean[] useIntegers) {
        // validate
        if (!(paramNames.length == mins.length && mins.length == maxs.length && maxs.length == defaults.length
                && defaults.length == useIntegers.length)) {
            throw new IllegalArgumentException("Length of parameter arrays doesn't match");
        }
        this.displayName = name;
        this.paramNames = paramNames;
        this.mins = mins;
        this.maxs = maxs;
        this.defaults = defaults;
        this.useIntegers = useIntegers;
    }

    /**
     * Get a StringConfig by its display name.
     * 
     * @param name the display name
     * @return the StringConfig or null
     */
    public static StringConfig forDisplayName(String name) {
        for (StringConfig sc : values()) {
            if (sc.getDisplayName().equals(name)) {
                return sc;
            }
        }
        return null;
    }

    /**
     * Get the display name of this config.
     * 
     * @return the displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Get the number of parameters
     * 
     * @return the number of parameters
     */
    public int getNumberOfParameters() {
        return paramNames.length;
    }

    /**
     * Search for a parameter by its name.
     * 
     * @param name the name
     * @return the index or -1 if it doesn't exist
     */
    public int getIndexOfParameter(String name) {
        for (int i = 0; i < paramNames.length; i++) {
            if (paramNames[i].equals(name)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Get the name of the parameters.
     * 
     * @return the parameter names
     */
    public String[] getParameterNames() {
        return Arrays.copyOf(paramNames, paramNames.length);
    }

    /**
     * Get the name of the parameter with the given index.
     * 
     * @param index the index
     * @return the name of the parameter
     */
    public String getParameterName(int index) {
        return paramNames[index];
    }

    /**
     * Get the minimum for a parameter.
     * 
     * @param index the index
     * @return the minimum value (inclusive)
     */
    public Number getMinimum(int index) {
        return mins[index];
    }

    /**
     * Get the default value for a parameter.
     * 
     * @param index the index
     * @return the default value
     */
    public Number getDefaultValue(int index) {
        return defaults[index];
    }

    /**
     * Get a copy of the default values.
     * 
     * @return the copy
     */
    public Number[] getCopyOfDefaults() {
        return Arrays.copyOf(defaults, defaults.length);
    }

    /**
     * Get the maximum for a parameter.
     * 
     * @param index the index
     * @return the maximum value (inclusive)
     */
    public Number getMaximum(int index) {
        return maxs[index];
    }

    /**
     * Test whether a parameter is an integer or floating point number.
     * 
     * @param index the index
     * @return true if the parameter is an integer, false otherwise
     */
    public boolean isInteger(int index) {
        return useIntegers[index];
    }

    /**
     * Test whether a number is a valid value
     * 
     * @param index the parameter index
     * @param val   the value
     * @return true if the value is valid, false otherwise
     */
    public boolean isValidValue(int index, Number val) {
        if (isInteger(index)) {
            // Check bounds for integer
            int v = val.intValue();
            return (v >= getMinimum(index).intValue() && v <= getMaximum(index).intValue());
        } else {
            // Check bounds for double
            double v = val.doubleValue();
            return (v >= getMinimum(index).doubleValue() && v <= getMaximum(index).doubleValue());
        }
    }
}
