/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.subtaxonomies.compilation;

import java.util.ArrayList;
import java.util.List;

import de.dfki.mycbr.core.casebase.SymbolAttribute;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.SymbolDesc;
import de.dfki.mycbr.core.similarity.Similarity;
import de.dfki.mycbr.core.similarity.TaxonomyFct;
import de.dfki.mycbr.core.similarity.config.TaxonomyConfig;
import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomyNode;

/**
 * @author myCBR Team
 *
 */
public class TaxonomyFctGenerator {

	public static TaxonomyFct subTaxonomyToTaxonomyFct(SubTaxonomyNode rootNode, SymbolDesc desc, Concept concept,
			TaxonomyConfig config) throws Exception {

		List<String> allChildren = getAllChildrenNames(rootNode);
		allChildren.add(rootNode.getId());
		for (String string : allChildren) {
			desc.addSymbol(string);
		}

		TaxonomyFct fct = desc.addTaxonomyFct(rootNode.getId(), true);
		/*
		 * gets the Similarity from the first child of the root node and sets it
		 * as similarity for our Taxonomy function
		 */
		fct.setNodeSimilarity(desc, Similarity.get(0D));

		SymbolAttribute firstNode = (SymbolAttribute) desc.getAttribute(rootNode.getId());
		fct.setNodeSimilarity(firstNode, Similarity.get(rootNode.getSimilarity()));
		fct.setQueryConfig(config);
		generateTaxonomy(fct, desc, rootNode);

		return fct;
	}

	private static void generateTaxonomy(TaxonomyFct fct, SymbolDesc desc, SubTaxonomyNode node) {
		List<SubTaxonomyNode> children = node.getChildren();
		// every child gets linked to its parent and is added to the taxonomy
		// function
		for (SubTaxonomyNode childNode : children) {
			SymbolAttribute curAtt = (SymbolAttribute) desc.getAttribute(childNode.getId());
//			System.out.println("add  " +  childNode.getId());
			
			// nach erfahrung ist bei grossen taxonomien die setParent() methode
			// sehr langsam
			// das liegt an dem bekannten problem. dass er so viele referenzen
			// für die similarityfunktion setzen muss
			fct.setParent(curAtt, (SymbolAttribute) desc.getAttribute(node.getId()));
			fct.setNodeSimilarity(curAtt, Similarity.get(childNode.getSimilarity()));
			// else {
			// fct.setNodeSimilarity(curAtt, Similarity.get(1.0));
			// }
			generateTaxonomy(fct, desc, childNode);
		}
	}

	private static List<String> getAllChildrenNames(SubTaxonomyNode rootnode) {
		List<String> namen = new ArrayList<String>();
		List<SubTaxonomyNode> children = rootnode.getChildren();
		for (SubTaxonomyNode node : children) {
			namen.add(node.getId());
			namen.addAll(getAllChildrenNames(node));
		}
		return namen;
	}

}
