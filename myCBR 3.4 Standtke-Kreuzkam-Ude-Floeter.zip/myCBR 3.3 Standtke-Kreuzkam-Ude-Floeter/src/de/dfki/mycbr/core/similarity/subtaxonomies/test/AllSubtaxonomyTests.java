package de.dfki.mycbr.core.similarity.subtaxonomies.test;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Test class that includes all written test cases.
 */
@RunWith(Suite.class)
@SuiteClasses({
        SubTaxonomyTest.class,
        TaxonomyCompilerTest.class,
        TaxonomyFctGeneratorTest.class
})
public class AllSubtaxonomyTests {
    // runs tests defined in SuiteClasses
}