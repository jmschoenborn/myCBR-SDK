/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.core.similarity.subtaxonomies.datastructure;

/**
 * @author myCBR Team
 *
 */
import java.util.List;

/**
 * The Class SubTaxonomy.
 */
public class SubTaxonomy {

	/** The root node. */
	private SubTaxonomyNode rootNode = null;

	/** The tree id. */
	private String id;

	/**
	 * Instantiates a new Tree.
	 *
	 * @param taxonomyId
	 *            the tree id
	 */
	public SubTaxonomy(String taxonomyId) {
		this.rootNode = new SubTaxonomyNode();
		this.id = taxonomyId;
	}

	/**
	 * Maps the similarities from [sim_root,1] to [0,1]
	 * 
	 * @param taxonomyId
	 *            the tree id
	 */
	public void normalize() {
		double originalRootSim = this.rootNode.getSimilarity();
		normalizeNodesRecursively(this.rootNode, originalRootSim);
	}

	private void normalizeNodesRecursively(SubTaxonomyNode node, double originalRootSim) {

		if (!(originalRootSim == 1 || originalRootSim == 0)) {

			//Map values to from [originalRootSim,1] to [0,1]
			double normalizedSim = (node.getSimilarity() - originalRootSim) / (1 - originalRootSim);
			node.setSimilarity(normalizedSim);

			for (SubTaxonomyNode child : node.getChildren()) {
				normalizeNodesRecursively(child, originalRootSim);
			}

		}
	}

	/**
	 * Gets root node.
	 *
	 * @return the root node
	 */
	public SubTaxonomyNode getRootNode() {
		return this.rootNode;
	}

	/**
	 * Gets id.
	 *
	 * @return the id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param the
	 *            id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Split taxonomy at node and return the 2nd half of the taxonomy as new
	 * Tree. The original taxonomy is directly altered so that the instance upon
	 * which this method is called will be the 1st half.
	 * 
	 * 
	 * @param node
	 *            the node
	 * @return the tree
	 */
	public static SubTaxonomy splitTaxonomy(SubTaxonomyNode node, String cutOffTaxonomyName) {

		// remove children from node
		List<SubTaxonomyNode> children = node.getChildren();
		node.removeAllChildren();
		node.setReferencedTreeId(node.getId());

		// assemble new tree with the previously removed children
		SubTaxonomy returnTaxonomy = new SubTaxonomy(cutOffTaxonomyName);
		SubTaxonomyNode returnTaxonomyRootNode = returnTaxonomy.getRootNode();

		// keep values from original tree
		returnTaxonomyRootNode.setId(node.getId());
		returnTaxonomyRootNode.setSimilarity(node.getSimilarity());

		for (SubTaxonomyNode child : children) {
			returnTaxonomyRootNode.addChild(child);
		}

		return returnTaxonomy;

	}

}
