/**
 * @author myCBR Team
 * @since myCBR 3.0.0
 */
package de.dfki.mycbr.junittest.casebase;
