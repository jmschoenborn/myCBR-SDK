/*
 * Decompiled with CFR 0.150.
 */
package de.dfki.mycbr.maintenance;


public class LocalMaintenanceMap extends MaintenanceMap {
    private static final long serialVersionUID = 2017962416689756104L;

    public LocalMaintenanceMap(String name, boolean type) {
        super(name, type);
    }
}

