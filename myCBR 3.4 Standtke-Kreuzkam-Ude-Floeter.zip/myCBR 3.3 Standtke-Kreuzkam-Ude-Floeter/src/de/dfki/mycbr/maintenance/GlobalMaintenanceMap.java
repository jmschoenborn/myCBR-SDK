/*
 * Decompiled with CFR 0.150.
 */
package de.dfki.mycbr.maintenance;


public class GlobalMaintenanceMap extends MaintenanceMap {
    private static final long serialVersionUID = -7217509763583978033L;

    public GlobalMaintenanceMap(String name, boolean type) {
        super(name, type);
    }
}

