/*
 * Decompiled with CFR 0.150.
 */
package de.dfki.mycbr.maintenance;

import java.io.Serializable;

public class Dependency implements Serializable {
    private static final long serialVersionUID = -4987345361331499277L;
    private String conceptFrom;
    private String knowledgeFrom;
    private String conceptTo;
    private String knowledgeTo;
    private boolean bidirectional;

    public Dependency() {
    }

    public Dependency(String conceptFrom, String knoweldgeFrom, String conceptTo, String knowledgeTo) {
        this.conceptFrom = conceptFrom;
        this.knowledgeFrom = knoweldgeFrom;
        this.conceptTo = conceptTo;
        this.knowledgeTo = knowledgeTo;
    }

    public String getConceptFrom() {
        return this.conceptFrom;
    }

    public void setConceptFrom(String conceptFrom) {
        this.conceptFrom = conceptFrom;
    }

    public String getKnowledgeFrom() {
        return this.knowledgeFrom;
    }

    public void setKnowledgeFrom(String knowledgeFrom) {
        this.knowledgeFrom = knowledgeFrom;
    }

    public String getConceptTo() {
        return this.conceptTo;
    }

    public void setConceptTo(String conceptTo) {
        this.conceptTo = conceptTo;
    }

    public String getKnowledgeTo() {
        return this.knowledgeTo;
    }

    public void setKnowledgeTo(String knowledgeTo) {
        this.knowledgeTo = knowledgeTo;
    }

    public boolean isBidirectional() {
        return this.bidirectional;
    }

    public void setBidirectional(boolean bidirectional) {
        this.bidirectional = bidirectional;
    }
}

