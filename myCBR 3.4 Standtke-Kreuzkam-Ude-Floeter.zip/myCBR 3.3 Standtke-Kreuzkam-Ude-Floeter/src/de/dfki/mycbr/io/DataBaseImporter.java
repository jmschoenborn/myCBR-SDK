/*
 * myCBR License 3.0
 * 
 * Copyright (c) 2006-2015, by German Research Center for Artificial Intelligence (DFKI GmbH), Germany
 * 
 * Project Website: http://www.mycbr-project.net/
 * 
 * This library is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU Lesser General Public License as published by 
 * the Free Software Foundation; either version 3 of the License, or 
 * (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License 
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 * 
 * Oracle and Java are registered trademarks of Oracle and/or its affiliates. 
 * Other names may be trademarks of their respective owners.
 * 
 * endOfLic */

package de.dfki.mycbr.io;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import de.dfki.mycbr.core.ICaseBase;
import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.core.casebase.Attribute;
import de.dfki.mycbr.core.casebase.Instance;
import de.dfki.mycbr.core.casebase.MultipleAttribute;
import de.dfki.mycbr.core.model.AttributeDesc;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.DoubleDesc;
import de.dfki.mycbr.core.model.FloatDesc;
import de.dfki.mycbr.core.model.IntegerDesc;
import de.dfki.mycbr.core.model.SymbolDesc;
import de.dfki.mycbr.util.Database;
import de.dfki.mycbr.util.Mapping;
import de.dfki.mycbr.util.Pair;

/**
 * class to import a casebase from a postgres database
 * 
 * @author myCBR Team, Pascal Reuss
 *
 */
public class DataBaseImporter {

    private static final Logger LOGGER = LogManager.getLogger(DataBaseImporter.class);

    private HashMap<Integer, Database> dbases;
    private Database db;

    private Concept concept;
    private Project project;

    private String seperatorMultiple = ",";

    private Connection con;
    private Statement pstmt;
    private ResultSet result;
    private String tablename;
    private String dbmapping;

    private int totalCaseCount;
    private int currentCaseCount;

    private int counter;

    private DataBaseImporterError error;

    private ICaseBase cb;

    /**
     * If true use the old (postgres) DatabaseImporter<br>
     * If false use the new General
     */
    private boolean usePostgresImport = true;

    /**
     * The columns in the import query. If null or empty all will be used.
     * (used by the general importer)
     */
    private List<String> importColumns = new ArrayList<>();

    private ArrayList<Mapping> AttributeDescName = new ArrayList<Mapping>();
    private HashMap<AttributeDesc, String> AttributesDescs = new HashMap<AttributeDesc, String>();
    private HashMap<String, AttributeDesc> Indicies = new HashMap<String, AttributeDesc>();
    private Vector<String> columnsToSkip = new Vector<String>();

    private HashSet<Pair<String, AttributeDesc>> invalidValues = new HashSet<Pair<String, AttributeDesc>>();

    Thread t;

    /**
     * Constructor for DataBaseImporter
     * 
     * @param id      of the database to use for the CaseBase
     * @param project used for the CaseBase
     * @param concept used for the CaseBase
     */
    public DataBaseImporter(int id, Project project, Concept concept, String dbmapping) {
        this.dbases = new HashMap<Integer, Database>();
        this.concept = concept;
        this.project = project;
        this.dbmapping = dbmapping;

        readMetaDataFromXML();
        connectToDatabase(id);
    }

    /**
     * Empty private ctor
     */
    private DataBaseImporter() {
        this.dbases = new HashMap<Integer, Database>();
    }
    /**
     * Create a new DatabaseImporter which is able to load from the postgres jdbc driver.
     * @param id the database id
     * @param project the project
     * @param concept the concept
     * @param dbmapping the path to the dbmapping file
     * @return the DatabaseImporter
     */
    public static DataBaseImporter createPostgresImporter(int id, Project project, Concept concept, String dbmapping) {
        return new DataBaseImporter(id, project, concept, dbmapping);
    }

    /**
     * Create a new DatabaseImporter which is able to load from any jdbc driver.
     * @param id the database id
     * @param project the project
     * @param concept the concept
     * @param dbmapping the path to the dbmapping file
     * @return the DatabaseImporter
     */
    public static DataBaseImporter createGeneralImporter(int id, Project project, Concept concept, String dbmapping) {
        DataBaseImporter dbi = new DataBaseImporter();
        dbi.project = project;
        dbi.concept = concept;
        dbi.dbmapping = dbmapping;
        dbi.usePostgresImport = false;

        dbi.readMetaDataFromXML();
        dbi.generalConnectToDatabase(id);

        return dbi;
    }

    /**
     * Change if this importer used the old postgres import
     * @param usePostgresImport the usePostgresImport to set
     */
    public void setUsePostgresImport(boolean usePostgresImport) {
        this.usePostgresImport = usePostgresImport;
    }

    /**
     * Check if this Importer used the old postgres import
     * @return if this importer used the old postgres specific import
     */
    public boolean usesPostgresImport() {
        return usePostgresImport;
    }

    /**
     * Set the list of columns in the import query. (used by the general importer)
     * 
     * @param importColumns the importColumns to set
     */
    public void setImportColumns(List<String> importColumns) {
        this.importColumns = importColumns;
    }

    /**
     * Get the list of columns in the import query. (used by the general importer)
     * 
     * @return the importColumns
     */
    public List<String> getImportColumns() {
        return importColumns;
    }

    /**
     * Load the jdbc driver.
     * 
     * @return {@code true} on success, {@code false} otherwise
     */
    private boolean loadDriver() {
        try {
            if (db.getDriverURL() != null) {
                // Load driver from jar file
                URL urlDriver;

                urlDriver = new URL(db.getDriverURL());
                URLClassLoader cl = URLClassLoader.newInstance(new URL[] { urlDriver });
                Object obj = cl.loadClass(db.getDriver()).getConstructor().newInstance();
                if (obj instanceof Driver) {
                    Driver loadedDriver = (Driver) obj;
                    DriverWrapper dw = new DriverWrapper(loadedDriver);
                    DriverManager.registerDriver(dw);
                    return true;
                } else {
                    LOGGER.error("Can't load driver");
                }
            } else {
                // Load from classpath
                Class.forName(db.getDriver());
                return true;
            }
        } catch (MalformedURLException e) {
            LOGGER.error("Can't parse driver url", e);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e) {
            LOGGER.error("Can't load driver", e);
        } catch (SQLException e) {
            LOGGER.error("Can't register driver", e);
        } catch (ClassNotFoundException e) {
            LOGGER.error("Can't find driver class", e);
        }
        return false;
    }

    /**
     * Establish a connection to a given postgreSQL Database
     * 
     * @return true if successful, false if connection cannot be established
     */
    public boolean connectToDatabase(int id) {

        db = dbases.get(id);

        boolean success = false;

        try {

            success = loadDriver();
            if (!success) {
                return false;
            }

            if (db.getUser() != null && db.getPwd() != null) {
                this.con = DriverManager.getConnection(db.getURL(), db.getUser(), db.getPwd());
            } else {
                this.con = DriverManager.getConnection(db.getURL());
            }

            this.pstmt = this.con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

            success = true;

        } catch (SQLException se) {
            error = DataBaseImporterError.DataBaseConnect;
            LOGGER.error(se.getLocalizedMessage(), se);
        }

        return success;
    }

    /**
     * Connect to a database.
     * @param id the id of the database
     * @return {@code true} on success, {@code false} othewise.
     */
    private boolean generalConnectToDatabase(int id) {
        db = dbases.get(id);

        boolean success = false;

        try {

            success = loadDriver();
            if (!success) {
                return false;
            }

            if (db.getUser() != null && db.getPwd() != null) {
                this.con = DriverManager.getConnection(db.getURL(), db.getUser(), db.getPwd());
            } else {
                this.con = DriverManager.getConnection(db.getURL());
            }

            success = true;

        } catch (SQLException se) {
            error = DataBaseImporterError.DataBaseConnect;
            LOGGER.error(se.getLocalizedMessage(), se);
        }

        return success;
    }

    /**
     * Reads the Data from the table of a given database
     * 
     * @param table         the name of the table to read the data from
     * @param filtercolumns an array with the names of the columns for a where
     *                      clause
     * @param filtervalues  an array with the values of the columns for a where
     *                      clause
     * @return true if data can be imported, false if not
     */
    public boolean readData(String table, String[] filtercolumns, String[] filtervalues) {

        boolean success = false;
        // Use Conceptname as table name
        if (table == null) {
            this.tablename = this.concept.getName();
        } else {
            this.tablename = table;
        }

        String SQL = "SELECT * FROM " + this.tablename + " WHERE TRUE";

        if (filtercolumns != null && filtervalues != null) {
            for (int i = 0; i < filtercolumns.length; i++) {
                SQL += " AND " + filtercolumns[i] + " = '" + filtervalues[i] + "'";
            }
        }

        try {

            // Gets the resultset
            result = this.pstmt.executeQuery(SQL);
            // counting the rows
            while (result.next()) {
                totalCaseCount++;
            }

            result.beforeFirst();

        } catch (SQLException se) {
            error = DataBaseImporterError.DataBaseConnect;
            LOGGER.error("SQLException while reading data", se);
        }

        return success;
    }

    /**
     * Method to get the columnNames of the table from which the data is read
     */
    public void readMetaDataFromDatabase(String table) {

        if (table == null) {
            this.tablename = this.concept.getName();
        } else {
            this.tablename = table;
        }

        String SQL = "SELECT column_name FROM information_schema.COLUMNS WHERE table_name = " + this.tablename;

        try {
            ResultSet metaresult = pstmt.executeQuery(SQL);
            metaresult.beforeFirst();

            while (metaresult.next()) {
                String column = result.getString("column_name");
                Mapping mapping = new Mapping(column, column);
                AttributeDescName.add(mapping);
            }

        } catch (SQLException se) {
            error = DataBaseImporterError.DataBaseConnect;
            LOGGER.error("SQLException while reading meta data", se);
        }
    }

    /**
     * Method to get the mapping for columns and attributes from an xml file
     * 
     */
    public void readMetaDataFromXML() {
        LOGGER.trace("Reading XML");
        try {
            File dmap = new File(dbmapping);

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(dmap);

            doc.getDocumentElement().normalize();
            // Getting database nodes
            NodeList databases = doc.getElementsByTagName("databases");
            
            // compatibility
            if(databases == null || databases.getLength() == 0) {
                databases = doc.getElementsByTagName("database");
            } else {
                databases = ((Element)databases.item(0)).getElementsByTagName("database");
            }

            // Running through all databases
            for (int i = 0; i < databases.getLength(); i++) {
                Database db = new Database();
                HashMap<String, HashMap<String, Object>> mappings = new HashMap<String, HashMap<String, Object>>();

                Node database = databases.item(i);

                NodeList nodes = database.getChildNodes();
                String name = "";
                String concept = "";

                for (int j = 0; j < nodes.getLength(); j++) {

                    Node column = nodes.item(j);

                    if (column.getNodeType() == Node.ELEMENT_NODE) {

                        // Getting the id
                        if (column.getNodeName().equals("id")) {
                            Element id = (Element) column;

                            NodeList idElementList = id.getChildNodes();

                            db.setId(Integer.parseInt(idElementList.item(0).getNodeValue()));
                            // Getting connection parameters
                        } else if (column.getNodeName().equals("connection")) {
                            Element connElement = (Element) column;

                            db.setHost(getValFromConnection(connElement, "host"));
                            db.setPort(getValFromConnection(connElement, "port"));
                            db.setUser(getValFromConnection(connElement, "user"));
                            db.setPwd(getValFromConnection(connElement, "pass"));
                            db.setDbname(getValFromConnection(connElement, "dbname"));
                            db.setDriver(getValFromConnection(connElement, "driver"));
                            db.setDbtype(getValFromConnection(connElement, "dbtype"));
                            db.setDbFile(getValFromConnection(connElement, "dbfile"));
                            db.setDriverURL(getValFromConnection(connElement, "driverurl"));
                            // Getting table mappings
                        } else if (column.getNodeName().equals("table")) {
                            HashMap<String, Object> tabledata = new HashMap<String, Object>();
                            ArrayList<Mapping> map = new ArrayList<Mapping>();
                            NodeList tableinf = column.getChildNodes();

                            for (int l = 0; l < tableinf.getLength(); l++) {

                                Node node = tableinf.item(l);
                                if (node.getNodeType() == Node.ELEMENT_NODE) {

                                    if (node.getNodeName().equals("name")) {

                                        Element nameElement = (Element) node;

                                        NodeList nameElementList = nameElement.getChildNodes();

                                        name = nameElementList.item(0).getNodeValue().trim();

                                    } else if (node.getNodeName().equals("concept")) {

                                        Element conceptElement = (Element) node;

                                        NodeList conceptElementList = conceptElement.getChildNodes();

                                        concept = conceptElementList.item(0).getNodeValue().trim();

                                    } else if (node.getNodeName().equals("column")) {

                                        Element columnElement = (Element) node;

                                        NodeList sourcelist = columnElement.getElementsByTagName("source");
                                        NodeList targetlist = columnElement.getElementsByTagName("target");

                                        Element source = (Element) sourcelist.item(0);
                                        Element target = (Element) targetlist.item(0);

                                        NodeList sourceElementList = source.getChildNodes();
                                        NodeList targetElementList = target.getChildNodes();

                                        Mapping mapping = new Mapping(sourceElementList.item(0).getNodeValue().trim(),
                                                targetElementList.item(0).getNodeValue().trim());

                                        map.add(mapping);
                                    }
                                }
                            }
                            tabledata.put("concept", concept);
                            tabledata.put("mapping", map);
                            mappings.put(name, tabledata);
                        }
                    }
                }
                db.setMappings(mappings);
                this.dbases.put(db.getId(), db);
            }

        } catch (SAXParseException err) {
            LOGGER.error("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId(), err);
        } catch (ParserConfigurationException pce) {
            LOGGER.error("ParserConfigurationException while parsing xml", pce);
        } catch (IOException ie) {
            LOGGER.error("IOException while parsing xml", ie);
        } catch (SAXException se) {
            LOGGER.error("SAXException while parsing xml", se);
        }

    }

    /**
     * Get a value from a connection element
     * 
     * @param connElement the connection element
     * @param name        the name
     * @return the value or null if the element doesn't exist
     */
    private String getValFromConnection(Element connElement, String name) {
        NodeList portElementList = connElement.getElementsByTagName(name);
        if (portElementList == null || portElementList.getLength() == 0) {
            return null;
        }
        Element port = (Element) portElementList.item(0);
        NodeList portElements = port.getChildNodes();

        if (portElements == null || portElements.getLength() == 0) {
            return null;
        }
        return portElements.item(0).getNodeValue().trim();
    }

    /**
     * method to add values from the table to an attributes allowed values Only for
     * used
     */
    public void addMissingValues() {
        // If missing values found
        if (error == DataBaseImporterError.ValueMissing) {
            error = null;

            for (Pair<String, AttributeDesc> entry : invalidValues) {

                AttributeDesc desc = entry.getSecond();
                String value = entry.getFirst();

                if (desc instanceof IntegerDesc) {
                    Integer v;
                    try {
                        v = Integer.parseInt(value);
                    } catch (NumberFormatException ne) {
                        // ToDo
                        continue;
                    }

                    IntegerDesc intDesc = (IntegerDesc) desc;
                    if (intDesc.getMin() > v) {
                        intDesc.setMin(v);
                    } else if (intDesc.getMax() < v) {
                        intDesc.setMax(v);
                    }

                } else if (desc instanceof FloatDesc) {
                    Float v;
                    try {
                        v = Float.parseFloat(value);
                    } catch (NumberFormatException ne) {
                        // ToDo
                        continue;
                    }

                    FloatDesc floatdesc = (FloatDesc) desc;
                    if (floatdesc.getMin() > v) {
                        floatdesc.setMin(v);
                    } else if (floatdesc.getMax() < v) {
                        floatdesc.setMax(v);
                    }

                } else if (desc instanceof SymbolDesc) {
                    SymbolDesc symdesc = (SymbolDesc) desc;
                    symdesc.addSymbol(value);
                }
            }

        }
    }

    /**
     * method to check if the read data is valid
     */
    public void checkData() {

        for (Mapping map : db.getMappings(tablename)) {

            AttributeDesc desc = concept.getAttributeDesc(map.getTarget());
            HashMap<String, Concept> con = concept.getAllSubConcepts();
            for (String s : con.keySet()) {
                Concept c = project.getConceptByID(s);
                desc = c.getAttributeDesc(map.getTarget());
            }
            // TODO Rekursiver Aufruf

            // Check if the columns from the database are part of the case structure
            if (desc == null) {
                // if not part of the structure ingnore
                columnsToSkip.add(map.getSource());
            } else {
                // if part, add to list
                AttributesDescs.put(desc, map.getSource());
                Indicies.put(map.getTarget(), desc);
            }

            // Checking what kind of Attribute (Integer, Float, Double, Symbol)
            for (Map.Entry<AttributeDesc, String> entry : AttributesDescs.entrySet()) {
                AttributeDesc d = entry.getKey();
                String col = entry.getValue();
                // Checking if values of IntegerDesc are valid and in range
                if (d instanceof IntegerDesc) {

                    try {
                        while (result.next()) {

                            Integer v = null;
                            int colindex = result.findColumn(col);
                            // If multiple values, database colum had to be of type String
                            if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {
                                String[] values = result.getString(col).split(seperatorMultiple);
                                if (values.length > 1) {
                                    d.setMultiple(true);
                                }

                                for (String s : values) {
                                    try {
                                        v = Integer.parseInt(s.trim());
                                    } catch (NumberFormatException ne) {
                                        invalidValues.add(new Pair<String, AttributeDesc>(s.trim(), d));
                                        continue;
                                    }
                                }

                                IntegerDesc intDesc = (IntegerDesc) d;
                                if (intDesc.getMin() > v || intDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Integer.toString(v), d));
                                }

                                // if only one value it could be an integer column
                            } else if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.Integer")) {
                                v = result.getInt(col);

                                IntegerDesc intDesc = (IntegerDesc) d;
                                if (intDesc.getMin() > v || intDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Integer.toString(v), d));
                                }
                            }

                        }
                        result.beforeFirst();
                    } catch (SQLException se) {
                        error = DataBaseImporterError.DataBaseConnect;
                        LOGGER.error(se.getLocalizedMessage(), se);
                    }

                    // Checking if values of Float are valid or in range
                } else if (d instanceof FloatDesc) {

                    try {
                        while (result.next()) {

                            Integer v = null;
                            int colindex = result.findColumn(col);
                            // If multiple values, database colum had to be of type String
                            if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {
                                String[] values = result.getString(col).split(seperatorMultiple);
                                if (values.length > 1) {
                                    d.setMultiple(true);
                                }

                                for (String s : values) {
                                    try {
                                        v = Integer.parseInt(s.trim());
                                    } catch (NumberFormatException ne) {
                                        invalidValues.add(new Pair<String, AttributeDesc>(s.trim(), d));
                                        continue;
                                    }
                                }

                                FloatDesc floatDesc = (FloatDesc) d;
                                if (floatDesc.getMin() > v || floatDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Float.toString(v), d));
                                }

                                // if only one value it could be an float column
                            } else if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.Float")) {
                                v = result.getInt(col);

                                FloatDesc floatDesc = (FloatDesc) d;
                                if (floatDesc.getMin() > v || floatDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Float.toString(v), d));
                                }
                            }

                        }
                        result.beforeFirst();
                    } catch (SQLException se) {
                        error = DataBaseImporterError.DataBaseConnect;
                        LOGGER.error(se.getLocalizedMessage(), se);
                    }

                    // Checking if values of Double are valid or in range
                } else if (d instanceof DoubleDesc) {

                    try {
                        while (result.next()) {

                            Integer v = null;
                            int colindex = result.findColumn(col);
                            // If multiple values, database colum had to be of type String
                            if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {
                                String[] values = result.getString(col).split(seperatorMultiple);
                                if (values.length > 1) {
                                    d.setMultiple(true);
                                }

                                for (String s : values) {
                                    try {
                                        v = Integer.parseInt(s.trim());
                                    } catch (NumberFormatException ne) {
                                        invalidValues.add(new Pair<String, AttributeDesc>(s.trim(), d));
                                        continue;
                                    }
                                }

                                DoubleDesc doubleDesc = (DoubleDesc) d;
                                if (doubleDesc.getMin() > v || doubleDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Double.toString(v), d));
                                }

                                // if only one value it could be an Double column
                            } else if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.Double")) {
                                v = result.getInt(col);

                                DoubleDesc doubleDesc = (DoubleDesc) d;
                                if (doubleDesc.getMin() > v || doubleDesc.getMax() < v) {
                                    invalidValues.add(new Pair<String, AttributeDesc>(Double.toString(v), d));
                                }
                            }

                        }
                        result.beforeFirst();
                    } catch (SQLException se) {
                        error = DataBaseImporterError.DataBaseConnect;
                        LOGGER.error(se.getLocalizedMessage(), se);
                    }

                    // Checking if the symbol and boolean values are allowed values
                } else if (d instanceof SymbolDesc) {
                    try {
                        while (result.next()) {

                            int colindex = result.findColumn(col);
                            if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {

                                SymbolDesc symbDesc = (SymbolDesc) d;

                                if (result.getString(col) != null) {

                                    String[] values = result.getString(col).split(seperatorMultiple);

                                    if (values.length > 1) {
                                        d.setMultiple(true);
                                    }

                                    for (String s : values) {
                                        if (!symbDesc.isAllowedValue(s.trim())) {
                                            s = s.replace(" ", "_");
                                            if (!symbDesc.isAllowedValue(s.trim())) {
                                                invalidValues.add(new Pair<String, AttributeDesc>(s.trim(), d));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        result.beforeFirst();
                    } catch (SQLException se) {
                        error = DataBaseImporterError.DataBaseConnect;
                        LOGGER.error("SQLException while checking data", se);
                    }
                }
            }
            if (invalidValues.size() != 0) {
                error = DataBaseImporterError.ValueMissing;
            }
        }
        LOGGER.info("All Data checked");

    }

    /**
     * maps the read data to cases
     */
    public void doImport() {
        if (usePostgresImport) {
            t = new Thread(new DataBaseThread());
        } else {
            t = new Thread(new GeneralImportRunnable());
        }
        t.start();
    }

    /**
     * Returns the TableName which should be used for import
     * 
     * @return TableName
     */
    public String getTableName() {
        return this.tablename;
    }

    /**
     * Sets the tablename which should be used for import
     * 
     * @param tablename
     */
    public void setTableName(String tablename) {
        this.tablename = tablename;
    }

    public int getTotalNumberOfCases() {
        return this.totalCaseCount;
    }

    public int getCurrentNumberOfCases() {
        return this.currentCaseCount;
    }

    public String getSeperatorMultiple() {
        return this.seperatorMultiple;
    }

    public void setSeperatorMultiple(String seperator) {
        this.seperatorMultiple = seperator;
    }

    /**
     * 
     * @return true when still importing, false otherwisec
     */
    public boolean isImporting() {
        return t.isAlive();
    }

    private class DataBaseThread implements Runnable {

        public void run() {

            for (Pair<String, AttributeDesc> p : invalidValues) {
                LOGGER.info("Pair: " + p.getSecond().getName() + ": " + p.getFirst());
                error = null;
            }

            if (error == null) {

                try {
                    if (cb == null) {
                        cb = concept.getProject().createDefaultCB("CB_" + tablename);
                        LOGGER.info("New case base created: " + cb.getName());
                    }
                } catch (Exception e) {
                    LOGGER.error("Exception while creating casebase", e);
                    return;
                }

                try {
                    result.beforeFirst();

                    while (result.next()) {

                        Instance i = new Instance(concept, concept.getName() + Integer.toString(counter++));

                        for (Mapping map : db.getMappings(tablename)) {

                            AttributeDesc desc = Indicies.get(map.getTarget());
                            if (desc == null) {
                                LOGGER.warn("DESC NULL: " + map.getTarget());
                            }
                            Integer colindex = result.findColumn(map.getSource());

                            if (desc.isMultiple()) {
                                if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {

                                    if (result.getString(colindex) != null) {

                                        String[] values = result.getString(colindex).split(seperatorMultiple);
                                        LinkedList<Attribute> list = new LinkedList<Attribute>();
                                        for (String s : values) {

                                            list.add(desc.getAttribute(s.trim()));
                                        }
                                        MultipleAttribute<AttributeDesc> multipleAtt = new MultipleAttribute<AttributeDesc>(
                                                desc, list);
                                        i.addAttribute(desc, multipleAtt);

                                    } else {
                                        LinkedList<Attribute> list = new LinkedList<Attribute>();
                                        MultipleAttribute<AttributeDesc> multipleAtt = new MultipleAttribute<AttributeDesc>(
                                                desc, list);
                                        i.addAttribute(desc, multipleAtt);
                                    }
                                }
                            } else {
                                if (result.getMetaData().getColumnClassName(colindex).equals("java.lang.String")) {
                                    i.addAttribute(Indicies.get(map.getTarget()), result.getString(colindex));

                                } else if (result.getMetaData().getColumnClassName(colindex)
                                        .equals("java.lang.Integer")) {
                                    i.addAttribute(Indicies.get(map.getTarget()), result.getInt(colindex));

                                } else if (result.getMetaData().getColumnClassName(colindex)
                                        .equals("java.lang.Float")) {
                                    i.addAttribute(Indicies.get(map.getTarget()), result.getFloat(colindex));

                                } else if (result.getMetaData().getColumnClassName(colindex)
                                        .equals("java.lang.Double")) {
                                    i.addAttribute(Indicies.get(map.getTarget()), result.getDouble(colindex));

                                } else if (result.getMetaData().getColumnClassName(colindex)
                                        .equals("java.lang.Boolean")) {
                                    i.addAttribute(Indicies.get(map.getTarget()), result.getBoolean(colindex));

                                }
                            }
                        }

                        cb.addCase(i);
                        currentCaseCount++;
                    }

                } catch (SQLException se) {
                    LOGGER.error("SQLException while importing cases", se);
                } catch (Exception e) {
                    LOGGER.error("Exception while importing cases", e);
                }

            }
        }
    }

    /**
     * A more general runnable than the {@code DataBaseThread}
     * 
     * @author myCBR Team
     */
    public class GeneralImportRunnable implements Runnable {

        @Override
        public void run() {

            if (tablename == null) {
                LOGGER.error("Tablename is null");
                return;
            }

            // Create result for table
            StringBuilder sql = new StringBuilder("SELECT ");
            if (importColumns == null || importColumns.isEmpty()) {
                sql.append('*');
            } else {
                for (int i = 0; i < importColumns.size() - 1; i++) {
                    sql.append('`');
                    sql.append(importColumns.get(i));
                    sql.append('`');
                    sql.append(',');
                }
                sql.append('`');
                sql.append(importColumns.get(importColumns.size() - 1));
                sql.append('`');
            }
            sql.append(" FROM ").append('`').append(tablename).append('`');
            
            counter = concept.getAllInstances().size();

            try (Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(sql.toString())){
                while (rs.next()) {
                    String newName;
                    do {
                        newName = concept.getName() + Integer.toString(counter);
                        ++counter;
                    } while (concept.getInstance(newName) != null);

                    Instance newInstance = new Instance(concept, newName);

                    for (Mapping m : db.getMappings(tablename)) {
                        String descName = m.getTarget();

                        AttributeDesc attrDesc = concept.getAttributeDesc(descName);
                        if (attrDesc == null) {
                            continue;
                        }

                        int columnIndex;
                        try {
                            columnIndex = rs.findColumn(m.getSource());
                        } catch(SQLException e) {
                            LOGGER.info("Cant' find column " + m.getSource(), e);
                            continue;
                        }

                        if (attrDesc.isMultiple()) {
                            String val = rs.getString(columnIndex);
                            if (val != null) {
                                String[] multipleVals = val.split(seperatorMultiple);
                                LinkedList<Attribute> list = new LinkedList<>();
                                for (String s : multipleVals) {
                                    try {
                                        list.add(attrDesc.getAttribute(s.trim()));
                                    } catch (ParseException e) {
                                        LOGGER.warn("Can't parse attribute", e);
                                    }
                                }
                                MultipleAttribute<AttributeDesc> multipleAtt = new MultipleAttribute<>(attrDesc, list);
                                newInstance.addAttribute(attrDesc, multipleAtt);
                            } else {
                                LinkedList<Attribute> list = new LinkedList<>();
                                MultipleAttribute<AttributeDesc> multipleAtt = new MultipleAttribute<>(attrDesc, list);
                                newInstance.addAttribute(attrDesc, multipleAtt);
                            }
                        } else {
                            Object obj = rs.getObject(columnIndex);
                            if (obj != null) {
                                try {
                                    newInstance.addAttribute(attrDesc, obj);
                                } catch (ParseException e) {
                                    LOGGER.error("Can't parse attribute", e);
                                }
                            }
                        }
                    }
                }
            } catch (SQLException e) {
                LOGGER.error("SQLException in GeneralImportRunnalbe::run()", e);
            }

        }

    }

    public enum DataBaseImporterError {
        DataBaseConnect("Could not connect to database"), ValueMissing("Values are Missing");

        private String desc;
        private String problem;

        DataBaseImporterError(String desc) {
            this.desc = desc;
        }

        public String getProblem() {
            return problem;
        }

        public void setProblem(String problem) {
            this.problem = problem;
        }

        public String getDesc() {
            return this.desc;
        }
    }

}
