/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.maintenance.MaintenanceController;

/**
 * @author myCBR Team
 *
 */
public class ObjectModelImporter {
	
	private Project prj;
	
	private String path;
	
	private ZipFile zipFile;
	
	private MaintenanceController crtl;
	
	private static final int BUFFER_SIZE = 1024;
	
	private String myCB = "";
    private String myCBR = "";
    private String myExp = "";
    private String myMmap = "";
	
	public ObjectModelImporter(final Project p) throws Exception {
		
		this.prj = p;
		this.path = prj.getPath() + prj.getName();
		
		this.zipFile = new ZipFile(prj.getPath() + prj.getName() + p.getExtension());
		
		this.crtl = p.getMaintenanceController();
		
	}
	
	public void doImport() {
		
		Enumeration<? extends ZipEntry> e = zipFile.entries();
        ZipEntry entry;
        System.out.println("Do the import");
        
        while (e.hasMoreElements()) {
            entry = (ZipEntry) e.nextElement();
            String filename = path
            .substring(0, path.lastIndexOf(File.separator))
            + File.separator + entry.getName();
            System.out.println("File: " +  filename);
            
            if (entry.getName().endsWith(".myCB")) {
            	myCB = filename;
            } else if (entry.getName().endsWith(".myCBR")) {
            	myCBR = filename;
            } else if (entry.getName().endsWith(".myExp")) {
            	myExp = filename;
            } else if (entry.getName().endsWith(".myMmap")) {
            	System.out.println(filename);
            	myMmap = filename;
            }
            
            try {
                copyInputStream(zipFile.getInputStream(entry),
                        new BufferedOutputStream(new FileOutputStream(filename)));
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        
        //Here doing the import
		MaintenanceMapImporter mmi = new MaintenanceMapImporter();
		mmi.doImport();
        
	}
	
	/**
     * Copies the given input stream to the output stream.
     * @param in input stream of file to be copied
     * @param out the output stream of the file to be written
     * @throws IOException if something goes wrong when reading/writing
     */
    public static void copyInputStream(final InputStream in,
            final OutputStream out)
            throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        int len;

        while ((len = in.read(buffer)) >= 0) {
            out.write(buffer, 0, len);
        }
        in.close();
        out.close();
    }
    
    
    
    private class MaintenanceMapImporter {
    	
    	
    	
    	public MaintenanceMapImporter() {
    		
    	}
    	
    	public void doImport() {
    		
    		System.out.println("Path " + myMmap);
    		crtl.loadAllMaintenanceMaps(myMmap);
    		
    	}
    	
    }
    

}
