/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.io;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomy;
import de.dfki.mycbr.core.similarity.subtaxonomies.datastructure.SubTaxonomyNode;

/**
 * @author myCBR Team
 *
 */
public class SubTaxonomyExporter {


	public static void exportTaxonomy(String targetFilePath, SubTaxonomy taxonomy)
			throws ParserConfigurationException, TransformerException {
		DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder icBuilder;
		try {
			icBuilder = icFactory.newDocumentBuilder();
			Document doc = icBuilder.newDocument();
			Transformer transformer = TransformerFactory.newInstance().newTransformer();

			Element rootElement = doc.createElement("SubTaxonomy");
			rootElement.setAttribute("id", taxonomy.getId());

			Element xmlRootNode = doc.createElement("SubTaxonomyNode");
			SubTaxonomyNode subTaxonomyRootNode = taxonomy.getRootNode();
			xmlRootNode.setAttribute("id", subTaxonomyRootNode.getId());
			xmlRootNode.setAttribute("sim", Double.toString(subTaxonomyRootNode.getSimilarity()));
			if (subTaxonomyRootNode.isReferencingNode()) {
				xmlRootNode.setAttribute("ref", subTaxonomyRootNode.getReferencedTreeId());
			} else {
				addChildrenToNode(doc, subTaxonomyRootNode, xmlRootNode);
			}
			rootElement.appendChild(xmlRootNode);

			doc.appendChild(rootElement);

			// Write file
			DOMSource source = new DOMSource(doc);

			File target = new File(targetFilePath);

			target.createNewFile();

			StreamResult streamResult = new StreamResult(target);
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
			transformer.transform(source, streamResult);

			System.out.println("XML DOM Created Successfully for :" + taxonomy.getId());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void addChildrenToNode(Document doc, SubTaxonomyNode taxNode, Element xmlNode) {
		for (SubTaxonomyNode taxChildNode : taxNode.getChildren()) {
			Element xmlChildNode = doc.createElement("SubTaxonomyNode");
			xmlChildNode.setAttribute("id", taxChildNode.getId());
			xmlChildNode.setAttribute("sim", Double.toString(taxChildNode.getSimilarity()));
			if (taxChildNode.isReferencingNode()) {
				xmlChildNode.setAttribute("ref", taxChildNode.getReferencedTreeId());
			} else {
				addChildrenToNode(doc, taxChildNode, xmlChildNode);
			}
			xmlNode.appendChild(xmlChildNode);
		}
	}

}
