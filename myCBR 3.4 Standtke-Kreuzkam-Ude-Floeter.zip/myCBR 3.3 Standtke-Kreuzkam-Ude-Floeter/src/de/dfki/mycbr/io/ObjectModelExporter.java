/*
 * myCBR License 2.0
 *
 * Copyright (c) 2009
 * Thomas Roth-Berghofer, Armin Stahl & Deutsches Forschungszentrum f&uuml;r K&uuml;nstliche Intelligenz DFKI GmbH
 * Further contributors: myCBR Team (see http://mycbr-project.net/contact.html for further information 
 * about the myCBR Team). 
 * All rights reserved.
 *
 * myCBR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Since myCBR uses some modules, you should be aware of their licenses for
 * which you should have received a copy along with this program, too.
 * 
 * endOfLic */

package de.dfki.mycbr.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.maintenance.MaintenanceController;
import de.dfki.mycbr.maintenance.MaintenanceMap;

/**
 * @author myCBR Team
 *
 */
public class ObjectModelExporter {
	
private Project prj;
	
	private String path;
	
	private ZipFile zipFile;
	
	private MaintenanceController crtl;
	
	private static final int BUFFER_SIZE = 1024;
	
	private String myCB = "";
    private String myCBR = "";
    private String myExp = "";
    private List<MaintenanceMap> myMmap;
	
	public ObjectModelExporter(final Project p) throws Exception {
		
		this.prj = p;
		this.path = prj.getPath() + prj.getName();
		
		this.zipFile = new ZipFile(prj.getPath() + prj.getName() + p.getExtension());
		
		this.myMmap = this.prj.getMaintenanceController().getMaintenanceMaps();
		
	}
	
	public void doExport() {
	
        //Here doing the export
		MaintenanceMapExporter mme = new MaintenanceMapExporter();
		mme.doExport();
        
	}
    
    
    
    private class MaintenanceMapExporter {
    	
    	
    	public MaintenanceMapExporter() {
    		
    	}
    	
    	public void doExport() {
    		
    		
    		
    	}
    	
    }

}
